-- Create and use the database
CREATE DATABASE IF NOT EXISTS JB_HiFi;
USE JB_HiFi;

-- Drop tables if they already exist to avoid errors during repeated runs (optional for testing)
DROP TABLE IF EXISTS SalesTransaction;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS Employee;

-- Create Customer table
CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    LoyaltyPoints INT DEFAULT 0
);

-- Create Product table
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    StockQuantity INT NOT NULL
);

-- Create SalesTransaction table
CREATE TABLE SalesTransaction (
    TransactionID INT PRIMARY KEY,
    CustomerID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

-- Create Employee table
CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    StoreLocation VARCHAR(100) NOT NULL,
    Role VARCHAR(50) NOT NULL
);

-- Insert sample customers
INSERT INTO Customer VALUES 
(1, 'John', 'Doe', 'john.doe@email.com', 200),
(2, 'Jane', 'Smith', 'jane.smith@email.com', 150),
(3, 'Mark', 'Johnson', 'mark.johnson@email.com', 300);

-- Insert sample products
INSERT INTO Product VALUES 
(1, 'Laptop', 'Electronics', 1200.00, 50),
(2, 'Smartphone', 'Electronics', 799.99, 100),
(3, 'Blender', 'Home Appliances', 150.00, 30);

-- Insert sample sales transactions
INSERT INTO SalesTransaction VALUES 
(1, 1, 1, 1, 1200.00),
(2, 2, 2, 2, 1599.98),
(3, 3, 3, 1, 150.00);

-- Insert sample employees
INSERT INTO Employee VALUES 
(1, 'Alice', 'Brown', 'Sydney', 'Sales Associate'),
(2, 'Bob', 'Davis', 'Sydney', 'Store Manager'),
(3, 'Charlie', 'Evans', 'Melbourne', 'Sales Associate');
